****************************************************
PHP and Scriptaculous Web 2.0 Application Interfaces 
****************************************************

Chapter 1  - No Code
Chapter 2  - Code Present
Chapter 3  - Code Present
Chapter 4  - Code Present
Chapter 5  - Code Present
Chapter 6  - Code Present
Chapter 7  - Code Present
Chapter 8  - Code Present
Chapter 9  - Code Present
Chapter 10 - Code Present
Chapter 11 - Code Present
Chapter 12 - Code Present
Chapter 13 - Code Present 

This folder contains ZIP files that contain the code for the respective chapters.